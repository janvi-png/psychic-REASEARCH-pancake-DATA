<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// Database connection parameters
$hostname = "localhost";
$username = "root";
$password = " ";
$database = "r&p";

// Connect to the database
$conn = new mysqli($hostname, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$title = $_POST['title'];
$year = $_POST['year'];
$author1 = $_POST['author1'];
$author2 = $_POST['author2'];
$author3 = $_POST['author3'];
$email2 = $_POST['email2'];
$email3 = $_POST['email3'];
$clg1 = $_POST['clg1'];
$clg2 = $_POST['clg2'];
$clg3 = $_POST['clg3'];

// Prepare SQL statement to insert data into 'author_details' table
$stmt = $conn->prepare("INSERT INTO author_details (title, year, author1, author2, author3, email2, email3, clg1, clg2, clg3) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sissssssss", $title, $year, $author1, $author2, $author3, $email2, $email3, $clg1, $clg2, $clg3);

// Execute SQL statement
if ($stmt->execute()) {
    // Success: Respond with success message
    echo "Author details saved successfully.";
} else {
    // Error: Respond with error message
    echo "Error: " . $conn->error;
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
